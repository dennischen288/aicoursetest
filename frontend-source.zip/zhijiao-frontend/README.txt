炙餃純前端網站

包含首頁、3D 動畫、PWA、PNG 圖示及前端示範購物車。
結帳不會將聯絡資料或訂單傳送到伺服器。
以 HTTP 本機伺服器或 HTTPS 靜態網站開啟；PWA 安裝及離線快取需要 HTTPS 或 localhost。

炙餃純前端網站

index.html：GitHub Pages 版本，保留原生 PWA 與 3D 動畫。
gas-frontend/Index.html：可貼入 Google Apps Script HTML 檔案的前端版本，使用原網站的 HTTPS 靜態資源；PWA 安裝入口另開原網站。
兩者皆為純前端示範結帳，不傳送訂單、不實際付款，沒有 Google Sheets／GAS 訂單後端。
PWA 安裝及離線快取需要 HTTPS 或 localhost。
